package com.example.lab6.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class UserController {
}
